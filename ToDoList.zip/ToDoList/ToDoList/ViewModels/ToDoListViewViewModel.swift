//
//  ToDoListViewViewModel.swift
//  ToDoList
//
//  Created by Giulia Martins on 12/31/23.
//

import FirebaseFirestore
import Foundation

// view model for the to do list
class ToDoListViewViewModel: ObservableObject {
    @Published var showingNewItemView = false 
    
    private let userId: String
    
    init(userId: String) {
        self.userId = userId
    }
    
    // delete todo list items
    func delete(id: String) {
        let db = Firestore.firestore()
        
        db.collection("users")
            .document(userId)
            .collection("todos")
            .document(id)
            .delete()
    }
}
